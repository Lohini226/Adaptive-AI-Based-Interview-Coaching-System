// db.js - the database layer. SQLite = one file on disk, no server to install.
const Database = require('better-sqlite3');
const fs = require('fs');
const path = require('path');

const dir = path.join(__dirname, 'data');
if (!fs.existsSync(dir)) fs.mkdirSync(dir);

const db = new Database(path.join(dir, 'coachline.db'));
db.pragma('journal_mode = WAL');

// Tables are created automatically the first time the server starts.
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS profiles (
    user_id         INTEGER PRIMARY KEY REFERENCES users(id),
    weak_topics     TEXT NOT NULL DEFAULT '{}',   -- JSON: { topic: {count, domain} }
    total_sessions  INTEGER NOT NULL DEFAULT 0,
    avg_score       INTEGER,
    last_difficulty INTEGER,
    updated_at      TEXT
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id  INTEGER NOT NULL REFERENCES users(id),
    date     TEXT NOT NULL,
    data     TEXT NOT NULL                        -- the whole session summary as JSON
  );
  CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id, date);
`);

const q = {
  createUser:   db.prepare('INSERT INTO users DEFAULT VALUES'),
  createProfile:db.prepare('INSERT INTO profiles (user_id) VALUES (?)'),
  userExists:   db.prepare('SELECT 1 FROM users WHERE id = ?'),
  getProfile:   db.prepare('SELECT * FROM profiles WHERE user_id = ?'),
  saveProfile:  db.prepare(`UPDATE profiles SET weak_topics=?, total_sessions=?, avg_score=?,
                            last_difficulty=?, updated_at=datetime('now') WHERE user_id=?`),
  addSession:   db.prepare('INSERT INTO sessions (user_id, date, data) VALUES (?, ?, ?)'),
  lastSessions: db.prepare('SELECT data FROM sessions WHERE user_id = ? ORDER BY date DESC LIMIT 30'),
};

function createUser() {
  const id = q.createUser.run().lastInsertRowid;
  q.createProfile.run(id);
  return Number(id);
}

function userExists(id) { return !!q.userExists.get(id); }

// Returns the profile in exactly the shape the front-end expects.
function getProfile(userId) {
  const p = q.getProfile.get(userId);
  const sessions = q.lastSessions.all(userId).map(r => JSON.parse(r.data)).reverse();
  return {
    sessions,
    weakTopics: JSON.parse(p.weak_topics || '{}'),
    totalSessions: p.total_sessions,
    avgScore: p.avg_score,
    lastDifficulty: p.last_difficulty,
  };
}

// Saves a finished interview session and updates the running totals.
const saveSession = db.transaction((userId, summary) => {
  q.addSession.run(userId, summary.date, JSON.stringify(summary));

  const profile = getProfile(userId);
  const scores = profile.sessions.map(s => s.overall).filter(n => typeof n === 'number');
  const avg = scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : null;

  const weak = profile.weakTopics;
  Object.entries(summary.weakTopics || {}).forEach(([topic, count]) => {
    const existing = weak[topic] || { count: 0 };
    weak[topic] = { count: existing.count + Number(count || 0), domain: summary.domain };
  });

  q.saveProfile.run(
    JSON.stringify(weak),
    profile.totalSessions + 1,
    avg,
    summary.finalDifficulty ?? null,
    userId
  );
  return getProfile(userId);
});

module.exports = { createUser, userExists, getProfile, saveSession };
