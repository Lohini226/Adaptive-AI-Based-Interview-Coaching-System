// server.js - the web server. Start here when reading the code.
require('dotenv').config();
const express = require('express');
const path = require('path');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const db = require('./db');
const ai = require('./ai');

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'dev-only-secret';
if (!process.env.JWT_SECRET) console.warn('! JWT_SECRET missing in .env - using an insecure dev secret');

app.use(express.json({ limit: '50kb' }));
app.use(express.static(path.join(__dirname, 'public'))); // serves index.html

// ---------- Helpers ----------
const str = (v, max = 500) => String(v ?? '').slice(0, max);
const strList = (v, max = 30) => (Array.isArray(v) ? v.slice(0, max).map(x => str(x, 500)) : []);

function cleanConfig(c = {}) {
  return {
    role: str(c.role, 120),
    domain: str(c.domain, 80),
    expLabel: str(c.expLabel, 80),
    topicFocus: str(c.topicFocus, 120),
  };
}

// Middleware: checks the "Authorization: Bearer <token>" header.
function auth(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  try {
    const { uid } = jwt.verify(token, JWT_SECRET);
    if (!db.userExists(uid)) return res.status(401).json({ error: 'Unknown user' });
    req.userId = uid;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or missing token' });
  }
}

// Rate limits protect your wallet: AI calls cost money.
const aiLimiter = rateLimit({ windowMs: 60_000, limit: 20, message: { error: 'Too many requests, slow down.' } });
const guestLimiter = rateLimit({ windowMs: 60 * 60_000, limit: 30 });

// ---------- Routes ----------
app.get('/api/health', (req, res) => res.json({ ok: true }));

app.get('/api/capabilities', (req, res) => res.json({ ai: ai.hasKey }));

// Creates an anonymous user and returns a login token (stored in the browser).
app.post('/api/auth/guest', guestLimiter, (req, res) => {
  const uid = db.createUser();
  const token = jwt.sign({ uid }, JWT_SECRET, { expiresIn: '365d' });
  res.json({ token });
});

app.get('/api/profile', auth, (req, res) => res.json(db.getProfile(req.userId)));

app.post('/api/sessions', auth, (req, res) => {
  const s = req.body || {};
  if (typeof s.overall !== 'number' || !s.date) return res.status(400).json({ error: 'Invalid session' });
  const summary = { ...s, role: str(s.role, 120), domain: str(s.domain, 80) };
  res.json(db.saveSession(req.userId, summary));
});

app.post('/api/question', auth, aiLimiter, async (req, res) => {
  if (!ai.hasKey) return res.status(503).json({ error: 'AI not configured' });
  try {
    const b = req.body || {};
    const qtype = ['technical', 'behavioral', 'hr'].includes(b.qtype) ? b.qtype : 'technical';
    const difficulty = Math.min(5, Math.max(1, parseInt(b.difficulty, 10) || 1));
    const data = await ai.generateQuestion({
      config: cleanConfig(b.config),
      qtype,
      difficulty,
      askedTopics: strList(b.askedTopics),
      askedQuestions: strList(b.askedQuestions),
      skippedQuestions: strList(b.skippedQuestions),
      attempt: Math.min(3, parseInt(b.attempt, 10) || 0),
      weakTopics: db.getProfile(req.userId).weakTopics,
    });
    if (!data || !data.question) throw new Error('Bad AI response');
    res.json({ question: str(data.question, 600), topic: str(data.topic, 60), qtype });
  } catch (err) {
    console.error('question error:', err.message);
    res.status(502).json({ error: 'AI request failed' });
  }
});

app.post('/api/evaluate', auth, aiLimiter, async (req, res) => {
  if (!ai.hasKey) return res.status(503).json({ error: 'AI not configured' });
  try {
    const b = req.body || {};
    const qa = {
      question: str(b.qa?.question, 600),
      topic: str(b.qa?.topic, 60),
      qtype: str(b.qa?.qtype, 20),
      answer: str(b.qa?.answer, 5000),
    };
    const data = await ai.evaluateAnswer({ config: cleanConfig(b.config), qa });
    res.json(data);
  } catch (err) {
    console.error('evaluate error:', err.message);
    res.status(502).json({ error: 'AI request failed' });
  }
});

app.listen(PORT, () => {
  console.log(`Coachline running at http://localhost:${PORT}`);
  console.log(ai.hasKey ? 'AI coach: ON' : 'AI coach: OFF (add ANTHROPIC_API_KEY to .env)');
});
