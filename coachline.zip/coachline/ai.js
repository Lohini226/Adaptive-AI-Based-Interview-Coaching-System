// ai.js - everything that talks to Claude. The API key lives ONLY here, on the server.
const Anthropic = require('@anthropic-ai/sdk');

const QTYPE_LABELS = { technical: 'Technical', behavioral: 'Behavioral', hr: 'HR / culture fit' };
const DIFF_LABELS = ['Warm-up', 'Building', 'Applied', 'Advanced', 'Expert'];

const hasKey = !!process.env.ANTHROPIC_API_KEY;
const client = hasKey ? new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY }) : null;
const MODEL = process.env.CLAUDE_MODEL || 'claude-sonnet-5-5';

async function askJson(prompt) {
  const res = await client.messages.create({
    model: MODEL,
    max_tokens: 800,
    messages: [{ role: 'user', content: prompt }],
  });
  const text = res.content.filter(b => b.type === 'text').map(b => b.text).join('');
  // The model is told "JSON only", but strip code fences just in case.
  const clean = text.replace(/```json|```/g, '').trim();
  return JSON.parse(clean);
}

async function generateQuestion({ config, qtype, difficulty, askedTopics, askedQuestions, skippedQuestions, attempt, weakTopics }) {
  const topWeak = Object.entries(weakTopics || {})
    .sort((a, b) => b[1].count - a[1].count).slice(0, 3).map(x => x[0]);

  const prompt = [
    'You are simulating a realistic, professional job interviewer conducting a live interview.',
    'Generate exactly ONE interview question. Return strict JSON only - no markdown fences, no commentary.',
    '',
    `Candidate's target role: ${config.role}`,
    `Domain: ${config.domain}`,
    `Candidate's experience level: ${config.expLabel}`,
    `Requested question type for this turn: ${QTYPE_LABELS[qtype]}`,
    `Current difficulty: level ${difficulty} of 5 (${DIFF_LABELS[difficulty - 1]})`,
    config.topicFocus
      ? `Focus this question specifically on this topic: "${config.topicFocus}". Stay on this topic even as the difficulty and question type change - for a behavioral or HR question type, relate the question to this topic where reasonably possible; if it truly doesn't fit, keep the question broadly relevant to the candidate's role.`
      : '',
    topWeak.length
      ? `The candidate has historically struggled with: ${topWeak.join(', ')}. About one in three questions, gently probe one of these if it fits the role - otherwise ignore this line.`
      : '',
    `Already covered this session - do not repeat these topics or questions: ${askedTopics.length ? askedTopics.join(', ') : 'none yet'}.`,
    askedQuestions.length
      ? `BANNED - already used this session. Do not ask any of these again, or a re-worded version: ${askedQuestions.map(q => `"${q}"`).join(' / ')}`
      : '',
    skippedQuestions.length
      ? `The candidate SKIPPED these, so they are off the table - pick a clearly different angle: ${skippedQuestions.map(q => `"${q}"`).join(' / ')}`
      : '',
    attempt > 0 ? 'Your previous attempt was too close to a question already used. Choose a different sub-topic and question structure.' : '',
    '',
    'Calibrate difficulty: level 1-2 is foundational/definitional; level 3 is applied/scenario-based; level 4-5 requires deep trade-off reasoning, systems thinking, or nuanced self-reflection.',
    "For a behavioral or HR question, phrase it the way a real interviewer would (e.g. 'Tell me about a time...' or 'Why...').",
    '',
    `Return exactly this JSON shape: {"question": "...", "topic": "a short 2-4 word topic label", "qtype": "${qtype}"}`,
  ].filter(Boolean).join('\n');

  return askJson(prompt);
}

async function evaluateAnswer({ config, qa }) {
  const prompt = [
    'You are an expert, constructive interview coach evaluating one candidate answer. Be honest but never cruel.',
    'Return strict JSON only - no markdown fences, no commentary.',
    '',
    `Question asked: "${qa.question}"`,
    `Topic: ${qa.topic}`,
    `Question type: ${QTYPE_LABELS[qa.qtype] || qa.qtype}`,
    `Candidate's target role: ${config.role} (${config.domain}, ${config.expLabel})`,
    `Candidate's answer: """${qa.answer || '(no answer given)'}"""`,
    '',
    'Score 0-100 on each: relevance (does it answer what was asked), clarity (easy to follow), completeness (covers the important points), communication (structure and professionalism), confidence (decisive, not evasive), technical (correctness/depth for technical questions - for behavioral/HR questions, score the soundness of reasoning and self-awareness instead).',
    'If no answer was given, score everything low and say so plainly but kindly.',
    'Also give: strengths (1-3 short phrases), weaknesses (1-3 short phrases), feedback (one short, second-person, actionable coaching sentence).',
    '',
    'Return exactly this shape: {"relevance":0,"clarity":0,"completeness":0,"communication":0,"confidence":0,"technical":0,"strengths":["..."],"weaknesses":["..."],"feedback":"..."}',
  ].join('\n');

  return askJson(prompt);
}

module.exports = { hasKey, generateQuestion, evaluateAnswer };
