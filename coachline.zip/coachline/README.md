# Coachline Backend - Beginner Guide

## What you have

```
coachline/
├── server.js        <- web server + all API routes (start reading here)
├── db.js            <- SQLite database (users, profiles, sessions)
├── ai.js            <- talks to Claude; your API key stays here, hidden from users
├── public/
│   └── index.html   <- your front-end, now calling the backend
├── package.json     <- list of libraries
├── .env.example     <- template for your secret settings
└── .gitignore
```

## How it works

```
Browser (index.html) --HTTP--> server.js --> db.js --> data/coachline.db
                                   |
                                   +--> ai.js --> Claude API
```

Before: the browser did everything. Now the browser only shows the UI and asks the server for things.

| Browser needs...          | Calls                | Server does                         |
|---------------------------|----------------------|-------------------------------------|
| A user identity           | POST /api/auth/guest | creates user, returns a login token |
| Saved progress            | GET  /api/profile    | reads database                      |
| Save a finished interview | POST /api/sessions   | stores it, updates averages         |
| A new question            | POST /api/question   | asks Claude, returns JSON           |
| Score an answer           | POST /api/evaluate   | asks Claude, returns scores         |

If the server or API key is missing, the app still works in "offline practice mode".

## Step-by-step setup

### Step 1: Install Node.js
Download the LTS version (18 or newer) from https://nodejs.org. Check it worked:
```
node -v
npm -v
```

### Step 2: Open the project folder in a terminal
```
cd path/to/coachline
```

### Step 3: Install the libraries
```
npm install
```
This creates a `node_modules` folder (never edit or upload it).

### Step 4: Get a Claude API key
1. Go to https://console.anthropic.com and create an account.
2. Add a little credit under Billing.
3. Create a key under API Keys and copy it.

### Step 5: Create your .env file
```
cp .env.example .env        # Windows: copy .env.example .env
```
Open `.env` and fill in:
```
ANTHROPIC_API_KEY=sk-ant-...your key...
JWT_SECRET=a-long-random-string
```
Generate a good secret: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

### Step 6: Run it
```
npm start
```
You should see:
```
Coachline running at http://localhost:3000
AI coach: ON
```
Open http://localhost:3000. The sidebar should say "AI coach active".
(`npm run dev` auto-restarts when you edit code.)

### Step 7: Test the API without the UI (optional)
```
curl -X POST http://localhost:3000/api/auth/guest
curl http://localhost:3000/api/profile -H "Authorization: Bearer PASTE_TOKEN"
```

### Step 8: Check data is saved
Finish a short interview, then refresh: your dashboard history remains.
The database file is `data/coachline.db` (open it with https://sqlitebrowser.org).
To reset everything, stop the server and delete the `data` folder.

## Troubleshooting

| Problem | Fix |
|---|---|
| "Offline practice mode" shown | Server not running, or ANTHROPIC_API_KEY empty/wrong. Check terminal logs. |
| npm install fails on better-sqlite3 | Use Node LTS (18/20/22). On Windows install "Build Tools for Visual Studio" if prompted. |
| Double-clicked index.html | It must be served by the server: use http://localhost:3000 |
| 401 errors | Clear the site's localStorage in the browser to get a fresh token. |
| Port in use | Set PORT=3001 in .env. |

## Deploying online
1. Push to GitHub (.env and data/ are git-ignored).
2. Host on Render, Railway or Fly.io (Node web service). Build: `npm install`, start: `npm start`.
3. Add ANTHROPIC_API_KEY and JWT_SECRET as environment variables in the host dashboard.
4. Attach a persistent disk mounted at `data/` so SQLite survives redeploys.

## Next steps
- Real accounts (email + password with bcrypt) so progress follows users across devices. The guest token is tied to one browser.
- Move SQLite to PostgreSQL if you expect many users.
- Add tests and logging.
- Already included: key kept server-side, input limits, rate limiting on AI routes, token auth.
